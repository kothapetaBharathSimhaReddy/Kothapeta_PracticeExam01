//
//  ViewController.swift
//  Kothapeta_PracticeExam01
//
//  Created by Bharath Simha Reddy Kothapeta on 9/24/24.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

